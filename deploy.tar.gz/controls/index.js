"use strict";

/**
 * Controls Index - DEPRECATED
 * 
 * All controls have been moved to isomorphic/controls/
 * This file redirects for backwards compatibility.
 * 
 * @deprecated Use require("../isomorphic/controls") instead
 */

module.exports = require("../isomorphic/controls");
