# Follow Ups

- Run API smoke test to verify background task and crawl routes respond with expected status codes once environment ready.
