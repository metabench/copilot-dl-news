# Search Index: 2025-11-15 Control Map Registration

| Keyword | Description | File |
|---------|-------------|------|
| map_Controls | Client-side control constructor registry populated during `update_Controls`. | PLAN.md |
| update_standard_Controls | Vendor helper that seeds the registry from `jsgui.controls`. | PLAN.md |
| CONTROL_MAP | Detailed flow covering global registry, context seeding, and Copilot hooks. | CONTROL_MAP.md |
