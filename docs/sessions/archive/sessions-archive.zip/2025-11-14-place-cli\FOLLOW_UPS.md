# Follow Ups — 2025-11-14 Place CLI Enablement

- _Pending_: Document open questions once CLI enhancements land.
