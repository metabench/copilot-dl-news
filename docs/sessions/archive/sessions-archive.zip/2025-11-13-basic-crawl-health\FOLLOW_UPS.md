# Follow Ups — Basic Crawl Health

| Item | Owner | Status | Notes |
|------|-------|--------|-------|
| Schedule controlled live basic crawl smoke test | TBD | Open | Requires environment with outbound access; would complement unit/integration coverage verified on 2025-11-13. |
| Diagnose repeated `ECONNRESET` failures + `problem_clusters.job_id` constraint during `ensureCountryHubs` | TBD | Open | Observed during 2025-11-13 live run; likely needs outbound network validation and schema guard for problem clustering. |
