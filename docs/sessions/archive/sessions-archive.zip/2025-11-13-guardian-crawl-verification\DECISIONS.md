# Decisions — Guardian Crawl Verification

_No material decisions recorded yet. Capture any CLI or crawler behavior choices here using ADR-lite structure (context, options, decision, consequences)._