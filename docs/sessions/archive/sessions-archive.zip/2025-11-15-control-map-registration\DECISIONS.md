# Decisions: 2025-11-15 Control Map Registration

| Date       | Decision | Context | Consequences |
|------------|----------|---------|--------------|
| _TBD_ | _Pending_ | Understanding map seeding | Document once a concrete approach is chosen. |
