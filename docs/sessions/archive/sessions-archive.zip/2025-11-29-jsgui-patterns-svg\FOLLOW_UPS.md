# Follow Ups – JSGUI3 patterns diagram

- Consider adding a tiny example snippet (compose vs activate) if future agents want code anchors.
- If patterns evolve (e.g., new activation hooks), refresh the SVG accordingly.
