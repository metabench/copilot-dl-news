# Working Notes — Front Page Seeding

## 2025-11-13
- Kickoff notes go here.
