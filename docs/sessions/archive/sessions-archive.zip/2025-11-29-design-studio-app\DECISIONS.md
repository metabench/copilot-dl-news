# Decisions – Design Studio Server App

| Date | Context | Decision | Consequences |
| --- | --- | --- | --- |
| 2025-11-29 | _Brief context_ | _Decision summary_ | _Impact / follow-ups_ |
