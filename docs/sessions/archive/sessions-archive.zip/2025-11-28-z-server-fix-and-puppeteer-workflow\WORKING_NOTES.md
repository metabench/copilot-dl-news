# Working Notes – Fix z-server and Improve Puppeteer Workflow

- 2025-11-28 — Session created via CLI. Add incremental notes here.
