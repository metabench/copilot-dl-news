# Decisions — 2025-11-14 Place CLI Enablement

_No decisions recorded yet._
