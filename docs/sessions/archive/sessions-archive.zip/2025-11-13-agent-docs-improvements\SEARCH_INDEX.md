# Search Index

- `Careful Builder.agent.md` — duplicated Jest guardrails, outdated CHANGE_PLAN reference.
- `Upgrade js-md-scan-edit.agent.md` — instructs use of legacy /docs/agents memory files instead of session docs.
- `Bilingual js tooling.agent.md` — bilingual workflow spec, lacks Gap 5/6 mention.
- `Singularity Engineer.agent.md` — strategic analysis brief, candidate for Gap 5/6/7 rollout guidance.
- `docs/sessions/SESSIONS_HUB.md` — now links to COMMAND_EXECUTION_GUIDE, TESTING_QUICK_REFERENCE, AGENT_REFACTORING_PLAYBOOK, and workflow docs.
