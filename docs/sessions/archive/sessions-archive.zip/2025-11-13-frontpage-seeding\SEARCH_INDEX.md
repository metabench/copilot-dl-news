# Search Index — Front Page Seeding

| Keyword | Context |
| --- | --- |
| `front page` | Ensure crawl starts from publication home page. |
| `hub reseeding` | Keep queue populated with topical/country hubs. |
| `url-table` | Persist new URLs and enqueue immediately. |
