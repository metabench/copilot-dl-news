# Decisions — Cached Seed Refactor

| Date | Context | Decision | Consequences |
| --- | --- | --- | --- |
