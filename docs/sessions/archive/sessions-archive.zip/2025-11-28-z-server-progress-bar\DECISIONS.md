# Decisions – Z-Server Scan Progress Bar

| Date | Context | Decision | Consequences |
| --- | --- | --- | --- |
| 2025-11-28 | _Brief context_ | _Decision summary_ | _Impact / follow-ups_ |
