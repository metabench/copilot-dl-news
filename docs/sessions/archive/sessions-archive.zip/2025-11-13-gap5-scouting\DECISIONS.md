# Decisions — Gap 5 Scouting & Feasibility

_Log ADR-lite entries here as decisions are made._

| 2025-11-13 | Gap 5 CLI delivery | Ship `--depends-on` + `--impacts` with path metadata & 16 tests | Enables agents to assess transitive risk quickly | Move to Gap 6 call graph design |
