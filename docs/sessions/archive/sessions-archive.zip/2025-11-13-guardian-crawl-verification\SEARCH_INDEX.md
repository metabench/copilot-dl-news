# Search Index — Guardian Crawl Verification

| Keyword | Context |
| --- | --- |
| `max-downloads 100` | Target crawl cap for verifying CLI summary output |
| `basicArticleDiscovery` | Sequence preset used for the Guardian crawl |
| `Final stats` | Log line confirming download/visit/save counts |
