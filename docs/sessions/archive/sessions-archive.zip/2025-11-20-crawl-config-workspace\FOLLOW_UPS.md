# Follow Ups

- Integrate `CrawlConfigWorkspaceControl` into whichever UI surface hosts crawl controls so operators can launch the drawer/timeline live.
- Enhance the diff mini-map builder to compare against priority config manifests once those files are populated.
- Consider exposing a CLI helper that emits the grouped workspace JSON so other agents can reuse it outside the check script.
