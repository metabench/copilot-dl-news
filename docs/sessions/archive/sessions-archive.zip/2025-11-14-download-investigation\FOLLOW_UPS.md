# Follow Ups

| Item | Status | Notes |
| --- | --- | --- |
| Confirm desired crawl mode | Open | Decide whether Guardian runs should flip `features.totalPrioritisation` off or supply an override when we need >51 downloads. |
| Instrument queue stats | Open | Capture `total-prioritisation-filter` drop counts + queue depth so we notice when the filter is trimming almost all work. |
