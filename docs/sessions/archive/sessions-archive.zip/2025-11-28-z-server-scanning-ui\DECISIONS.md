# Decisions – Add Scanning UI to Z-Server

| Date | Context | Decision | Consequences |
| --- | --- | --- | --- |
| 2025-11-28 | _Brief context_ | _Decision summary_ | _Impact / follow-ups_ |
