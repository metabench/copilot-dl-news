# Search Index

| Keyword | Context |
| --- | --- |
| `_emitPageLog` | Central logging helper ensuring each crawl fetch emits concise CLI output. |
| `PageExecutionService` | Primary crawl executor containing the missing log emission paths. |
| `PAGE` event | JSON line consumed by `progressAdapter` for per-page status display. |
