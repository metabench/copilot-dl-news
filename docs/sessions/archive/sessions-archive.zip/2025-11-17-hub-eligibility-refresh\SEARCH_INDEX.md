# Search Index — 2025-11-17 Hub Eligibility Refresh

| Keyword | File | Context |
|---------|------|---------|
| maxAgeHubMs | WORKING_NOTES.md | Tracking hub freshness overrides for queue eligibility |
| UrlEligibilityService | ROADMAP.md | Target for nav reseeding changes |
| hub freshness tests | WORKING_NOTES.md | Jest coverage for stale vs. fresh nav URLs |
