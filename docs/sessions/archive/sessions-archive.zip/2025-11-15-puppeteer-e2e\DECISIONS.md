# Decisions

| Date | Context | Decision | Consequences |
| --- | --- | --- | --- |
