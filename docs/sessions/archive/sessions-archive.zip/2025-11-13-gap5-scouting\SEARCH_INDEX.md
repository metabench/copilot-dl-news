# Search Index — Gap 5 Scouting & Feasibility

| Keyword | File | Context |
|---------|------|---------|
| `--depends-on` | WORKING_NOTES.md | Verified flag not present in current js-scan implementation |
| `runDependencySummary` | WORKING_NOTES.md | Existing helper for building dependency graphs; candidate for Gap 5 reuse |
| `dependencyTraversal.test.js` | tests/tools/js-scan/operations/dependencyTraversal.test.js | Gap 5 test coverage for CLI & path metadata |
