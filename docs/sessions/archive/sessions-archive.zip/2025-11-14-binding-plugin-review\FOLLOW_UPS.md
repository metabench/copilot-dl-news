# Follow Ups

1. Decide whether the remaining "Missing context.map_Controls for type ..." activation logs should become structured warnings (with additional context) or be removed once we confirm the controls list is intentionally sparse.
