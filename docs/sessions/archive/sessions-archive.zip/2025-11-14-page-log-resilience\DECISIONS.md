# Decisions

| Date | Context | Decision | Consequences |
| --- | --- | --- | --- |
| _TBD_ | Missing `_emitPageLog` on certain failure exits | _TBD_ | _TBD_ |
