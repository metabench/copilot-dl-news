# Search Index — 2025-11-14 Place CLI Enablement

- `crawl.js` — CLI entry point targeted for place workflow exposure (see plan).
- `GuessPlaceHubsOperation` — planned new operation wrapper for orchestrator integration.
- `place guess` — new subcommand hooking GuessPlaceHubs into `crawl.js` with summary/json modes.
- `place explore` — wrapper around `findPlaceAndTopicHubs` with friendly flag parsing.
