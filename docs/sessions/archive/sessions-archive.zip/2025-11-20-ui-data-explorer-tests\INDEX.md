# Session Index — 2025-11-20 UI Data Explorer Production Tests

- [Plan](./PLAN.md)
- [Working Notes](./WORKING_NOTES.md)
- [Session Summary](./SESSION_SUMMARY.md) *(to be written)*
- [Follow Ups](./FOLLOW_UPS.md) *(to be written)*
