# Follow Ups — Gap 5 Scouting & Feasibility

| Priority | Item | Owner | Status | Notes |
|----------|------|-------|--------|-------|
| 🟢 | Gap 5 dependency traversal flags live | Complete | ✅ | `--depends-on` & `--impacts` released with tests |
| 🔴 | Implement Gap 6 (call graph, hot paths, dead code) | Pending | ⏳ | Requires graph infrastructure planning |
