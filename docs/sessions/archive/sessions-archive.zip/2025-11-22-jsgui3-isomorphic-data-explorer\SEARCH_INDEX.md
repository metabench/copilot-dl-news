[
  {
    "keywords": ["data", "explorer", "ui", "layout", "css", "wide", "typography"],
    "context": "Refreshed Data Explorer UI with wide-screen support and polished typography.",
    "file": "src/ui/render-url-table.js"
  },
  {
    "keywords": ["check", "script", "preview", "html"],
    "context": "Added check script for generating Data Explorer HTML previews.",
    "file": "src/ui/server/checks/dataExplorer.check.js"
  }
]
