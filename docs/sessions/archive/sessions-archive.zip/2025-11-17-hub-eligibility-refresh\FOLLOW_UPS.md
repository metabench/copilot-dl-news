# Follow Ups — 2025-11-17 Hub Eligibility Refresh

| Item | Owner | Status | Notes |
|------|-------|--------|-------|
| Ensure front-page seeding leverages new eligibility logic | Agents | Pending | Verify planner reseeding once queue honors `maxAgeHubMs`. |
| Consider exposing `maxAgeHubMs` defaults in CLI docs | Agents | Pending | Document recommended values so operators know how to force nav refreshes. |
