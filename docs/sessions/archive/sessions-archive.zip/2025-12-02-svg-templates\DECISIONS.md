# Decisions – SVG Templates Expansion

| Date | Context | Decision | Consequences |
| --- | --- | --- | --- |
| 2025-12-02 | _Brief context_ | _Decision summary_ | _Impact / follow-ups_ |
