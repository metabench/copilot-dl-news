# Follow Ups – Create AGI Brainstorm agent

- First time the Brainstorm agent is invoked, capture lessons learned in `/docs/agi/LESSONS.md` and update this agent file if new facilitation tactics emerge.
