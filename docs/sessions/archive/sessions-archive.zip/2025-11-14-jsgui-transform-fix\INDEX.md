# Session 2025-11-14 – jsgui transform fix

**Focus**: Patch vendored `jsgui3-gfx-core` helpers so the esbuild UI bundle can run without `ReferenceError` and document the change.

## Quick Links
- [Plan](./PLAN.md)
- [Working Notes](./WORKING_NOTES.md)
- [Session Summary](./SESSION_SUMMARY.md)
- [Follow Ups](./FOLLOW_UPS.md)
