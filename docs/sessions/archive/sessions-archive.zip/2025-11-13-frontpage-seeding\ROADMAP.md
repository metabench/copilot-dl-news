# Roadmap — Front Page Seeding

## Current Tasks
1. Understand current crawl entry behavior and queue state.
2. Implement front page + hub reseeding.
3. Ensure URL discovery persists into URLs table and queue.

## Upcoming
- Add telemetry covering queue depth + URL discoveries.

## Blockers
- None yet.
