# Follow Ups — Crawl Config Runner

| Item | Owner | Status | Notes |
| --- | --- | --- | --- |
| Backfill automated tests for runner manifest loader | Platform | Open | Add unit tests covering JSON+YAML parsing, override precedence, and error handling for `--config` paths. |
