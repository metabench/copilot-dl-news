# Follow-Ups – Improve jsgui3 Workflow Access

- Investigate md-scan enhancements (e.g., canned search presets or tag filters) so agents can open workflow sections with a single command.
# Follow Ups – Improve jsgui3 Workflow Access

- _Add actionable follow-ups here._
