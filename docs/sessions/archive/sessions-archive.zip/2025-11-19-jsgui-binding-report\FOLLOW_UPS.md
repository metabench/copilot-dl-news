# Follow Ups — 2025-11-19 jsgui Binding Report

| Status | Item | Owner | Notes |
| --- | --- | --- | --- |
| ⏳ | Decide whether `Data_Value.normalize` lives in lang-tools or jsgui shim | Platform | Blocks eliminating local unwrapping helpers |
| ⏳ | Implement DOM binding metadata serialization in jsgui3-html | Platform | Needed before we can drop manual `pre_activate` wiring |
