const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const jsgui = require('jsgui3-html');
const { createCrawlSpeedometerControl, CRAWL_SPEEDOMETER_STYLES } = require('./controls/CrawlSpeedometerControl');

const app = express();
const PORT = process.env.PORT || 3120;
const DB_PATH = process.env.DB_PATH || 'crawler.db';

// Database Setup
const db = new Database(DB_PATH);
db.exec(`
  CREATE TABLE IF NOT EXISTS urls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT UNIQUE,
    status TEXT DEFAULT 'pending',
    depth INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS stats (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    total INTEGER DEFAULT 0,
    processed INTEGER DEFAULT 0,
    errors INTEGER DEFAULT 0
  );
  INSERT OR IGNORE INTO stats (id) VALUES (1);
`);

const CrawlSpeedometer = createCrawlSpeedometerControl(jsgui);

// UI Rendering
app.get('/', (req, res) => {
    const ctx = new jsgui.Page_Context();
    const page = new jsgui.Standard_Web_Page({ context: ctx });

    page.head.add(new jsgui.Control({ context: ctx, tagName: 'title', text: 'Remote Crawler Lab' }));
    const style = new jsgui.Control({ context: ctx, tagName: 'style' });
    style.add(CRAWL_SPEEDOMETER_STYLES);
    style.add(`
    body { background: #0d1117; color: #c9d1d9; font-family: sans-serif; display: flex; justify-content: center; padding-top: 50px; }
  `);
    page.head.add(style);

    const speedometer = new CrawlSpeedometer({
        context: ctx,
        label: 'Remote SQLite Crawler',
        maxSpeed: 10,
        showStats: true
    });
    // Initialize with empty data (client will poll)
    page.body.add(speedometer);

    // Client Script for Polling
    const script = new jsgui.Control({ context: ctx, tagName: 'script' });
    script.add(`
    setInterval(async () => {
      try {
        const res = await fetch('/api/stats');
        const data = await res.json();
        // Assuming the control exposes an update method accessible via DOM if we had one,
        // but typically jsgui renders static HTML unless client-side JS is bound.
        // For this lab, we'll just reload or update generic elements if we can.
        // Actually, the speedometer control logic in the original file might be purely server-side rendered?
        // Let's check. If so, we need to send data to constructor.
        // But for "live" updates, we need client code.
        // For now, let's just log.
        console.log('Stats:', data);
        
        // Basic DOM update if strict update() isn't available
        const needle = document.querySelector('.speedometer-needle');
        if (needle) {
             // Calculate angle
             const speedRatio = Math.min(data.speed / 10, 1);
             const angle = 180 + (speedRatio * 180);
             needle.setAttribute('transform', \`rotate(\${angle}, 80, 80)\`); // cx,cy hardcoded 80 based on 160 size
        }
        document.querySelector('.stat-item .stat-value').textContent = data.total;
        
      } catch(e) console.error(e);
    }, 1000);
  `);
    page.body.add(script);

    res.send(page.all_html_render());
});

app.get('/api/stats', (req, res) => {
    const stats = db.prepare('SELECT total, processed, errors FROM stats WHERE id = 1').get();
    // Mock speed for now
    res.json({ ...stats, speed: Math.random() * 5 });
});

app.listen(PORT, () => {
    console.log(`Remote Crawler Lab running on port ${PORT}`);
});
